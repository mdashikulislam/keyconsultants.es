@extends('frontend.layouts.inner-master')
@section('breadcumb-title')
    ACTING AS YOUR POWER OF ATTORNEY
@endsection
@section('content')
    <div class="content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 col-12">
                    <div class="property-content">
                        <p class="MsoNormal">
                            <b><u>Acting as your power of Attorney</u></b>
                        </p>
                        <p class="MsoNormal">
                            If you own a second home here on the island or are looking to buy a property and cannot
                            be here for the notary appointment, why not let Key Consultants act as your
                            representative in front of the notary and sell or buy your property for you.
                        </p>
                        <p class="MsoNormal">
                            As you appointed power of attorney, you will authorise us to obtain a copy of your deeds
                            from the land registry (<i>nota Simple</i>), obtain Plus Valia documents from the Local
                            Town Hall, where relevant request a certificate from the community that you are up to
                            date with your community fees, Deposit cheques into your bank account here in Spain or
                            third party bank accounts (such as a money transfer companies), pay taxes on your behalf
                            and changed utility contracts out of your name. And of course, act as your
                            representative in front of the Notary Public.
                        </p>
                        <p class="MsoNormal">
                            In order to appoint us as your power of attorney, you will need to prepare and grant a
                            Power of Attorney (poder de representacion)&nbsp; in front of a notary public.
                        </p>
                        <p class="MsoNormal">
                            We use and recommend the services of a local notary public here in Santa Ponça who we
                            have built a great relationship with over the years:-
                        </p>
                        <p class="MsoNormal" style="margin-bottom: 0.0001pt">
                            <strong>Maria Natavidad Mayol</strong> <strong>Contrereas.</strong>
                        </p>
                        <p class="MsoNormal" style="margin-bottom: 0.0001pt">Jaime I ,</p>
                        <p class="MsoNormal" style="margin-bottom: 0.0001pt">07180 Santa Ponsa</p>
                        <p>&nbsp;</p>
                        <p class="MsoNormal">
                            Please speak with us before contacting and appointing &nbsp;us at the notary as,
                            depending on your instructions and particular circumstances, will depend on the wording
                            of the power of attorney documentation.
                        </p>
                        <p class="MsoNormal">
                            If you would like further information on how we can assist you in front of the notary,
                            please do not hesitate to contact us.
                        </p>
                        <p class="MsoNormal">
                            Our charges for this service depend on the number of buyers and sellers.
                        </p>
                        <p class="MsoNormal">Please see our terms and conditions</p>
                        <div class="text-center mt-50">
                            <a href="{{route('contact')}}" class="contact-btn">Get Quote</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('frontend.include.contact-banner')
    <div class="featured-area">
        <div class="container">
            <h2 class="featured-title">Amongst other things our Administración de Fincas services includes:</h2>
        </div>
        <div class="featured-background">
            <div class="featured-shape" data-negative="false">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1800 5.8" preserveAspectRatio="none">
                    <path
                        class="elementor-shape-fill"
                        d="M5.4.4l5.4 5.3L16.5.4l5.4 5.3L27.5.4 33 5.7 38.6.4l5.5 5.4h.1L49.9.4l5.4 5.3L60.9.4l5.5 5.3L72 .4l5.5 5.3L83.1.4l5.4 5.3L94.1.4l5.5 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.4 5.3L161 .4l5.4 5.3L172 .4l5.5 5.3 5.6-5.3 5.4 5.3 5.7-5.3 5.4 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.5 5.3L261 .4l5.4 5.3L272 .4l5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.1l5.7-5.4 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.7-5.3 5.4 5.4h.2l5.6-5.4 5.5 5.3L361 .4l5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.1l5.7-5.4 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.1l5.6-5.4 5.5 5.3L461 .4l5.5 5.3 5.6-5.3 5.4 5.3 5.7-5.3 5.4 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.1L550 .4l5.4 5.3L561 .4l5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.4 5.3 5.7-5.3 5.4 5.3 5.6-5.3 5.5 5.4h.2L650 .4l5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.4h.2L750 .4l5.5 5.3 5.6-5.3 5.4 5.3 5.7-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.1l5.7-5.4 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.4h.2L850 .4l5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.4 5.3 5.7-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.1l5.7-5.4 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.4 5.3 5.7-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.1l5.7-5.4 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.1l5.7-5.4 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.7-5.3 5.4 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.1l5.6-5.4 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.7-5.3 5.4 5.4h.2l5.6-5.4 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.1l5.7-5.4 5.4 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.5 5.4h.1l5.6-5.4 5.5 5.3 5.6-5.3 5.5 5.3 5.6-5.3 5.4 5.3 5.7-5.3 5.4 5.3 5.6-5.3 5.5 5.4V0H-.2v5.8z"
                    ></path>
                </svg>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h3 class="featured-subtitle">HERE ARE SOME OF THE THINGS THAT WE INCLUDE:</h3>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                The Property Administrator acts as Secretary and Administrator and calls ordinary
                                meetings, sends Minutes, liquidations, etc.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                We have a meeting room at no additional cost, and with a max. 25 people, if they do
                                not have a meeting place or we move to the place designated by the community to hold
                                the meetings.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                Follow-up of the defaulters and their subsequent claim through the courts through
                                “payment orders” (whose preparation fees, lawyers and court costs are always borne
                                by the defendants).
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                In communities, where there is a large presence of foreign owners, we manage the
                                documentation with translations into English or German.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                Preparation and sending of expense settlements (as agreed in the Meeting). The
                                Administration can prepare settlements with the frequency set by the Community:
                                monthly, bi-monthly, quarterly, quarterly, semi-annually, annually by installments,
                                by budget
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                In the case of recently built buildings, our work ranges from the drafting of the
                                Statutes, constitution of the community fund, registration of community and
                                individual accountants, legalization of the Minutes Book, various steps with the
                                developer, CIF processing, procedures for obtaining ford, high lines telephone for
                                the elevators, search and contracting of cleaning services, surveillance, porter,
                                integral maintenance, etc.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                Attend to the maintenance of the building, its facilities and the proper functioning
                                of the contracted services, for which we have the collaboration of a wide range of
                                industrialists that fully cover any type of unforeseen event and works. We request
                                two estimates, as well as incident management.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                Bank management of the current account of the community, as authorized, we manage
                                the day to day of their operations working with the main banking entities.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                All those procedures processed before public bodies and monitoring by the
                                Administrator of the repairs and / or improvements to be made.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                Management of the Organic Law on Data Protection: owners, security surveillance,
                                etc. With the collaboration of Conversia, leader in the protection management
                                sector.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                Process contracts and attend to payments related to the personnel at the service of
                                the community; such as doorman, maintainer, gardener, night watch, etc.
                            </p>
                        </div>
                    </div>
                    <div class="col-md-6 col-12 mb-30">
                        <div class="featured-wrap">
                            <p>
                                Search for the most suitable insurance for the community, with adjusted premiums,
                                and claims processing.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
