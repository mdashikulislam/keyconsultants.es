@include('frontend.layouts.header')

@section('content')

@show
@include('frontend.layouts.footer')
